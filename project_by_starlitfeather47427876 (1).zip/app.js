class FinancialTrackerApp {
  constructor() {
    this.budgets = [];
    this.expenses = [];
    this.reminders = [];
    this.savigs = 0;
    this.totalBalance = 0; // For the home page balance
    this.savings = { amountSaved: 1400, goal: 5500, maturityDate: '16/04/2025' };
    this.initializeEventListeners();
    this.initializeSettingsButtons();
    this.loadStoredData();
  }

  initializeEventListeners() {
    // Navigation buttons
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => {
      btn.addEventListener('click', () => this.navigateScreen(btn.id));
    });

    // Budget Form
    const budgetForm = document.getElementById('budgetForm');
    budgetForm.addEventListener('submit', (e) => {
      e.preventDefault();
      this.createBudget(budgetForm);
    });

    // Expense Form
    const expenseForm = document.getElementById('expenseForm');
    expenseForm.addEventListener('submit', (e) => {
      e.preventDefault();
      this.addExpense(expenseForm);
    });

    // Reminder Form
    const reminderForm = document.getElementById('reminderForm');
    reminderForm.addEventListener('submit', (e) => {
      e.preventDefault();
      this.createReminder(reminderForm);
    });

    // Quick Action Buttons
    document.getElementById('addExpenseBtn').addEventListener('click', () => {
      this.navigateScreen('expensesBtn');
    });

    document.getElementById('createBudgetBtn').addEventListener('click', () => {
      this.navigateScreen('budgetBtn');
    });

    document.getElementById('addReminderBtn').addEventListener('click', () => {
      this.navigateScreen('remindersBtn');
    });

    // Total Balance Save
    document.getElementById('saveBalanceBtn').addEventListener('click', () => {
      this.saveTotalBalance();
    });

    // Savings Add Funds / Withdraw
    document.getElementById('addSavingsBtn').addEventListener('click', () => {
      this.updateSavings('add');
    });

    document.getElementById('withdrawSavingsBtn').addEventListener('click', () => {
      this.updateSavings('withdraw');
    });
  }

  initializeSettingsButtons() {
    const settingsBtn1 = document.getElementById('settingsBtn1');
    const settingsBtn2 = document.getElementById('settingsBtn2');
    const settingsBtn3 = document.getElementById('settingsBtn3');

    settingsBtn1.addEventListener('click', () => {
      this.showSettingsModal('General Settings');
    });

    settingsBtn2.addEventListener('click', () => {
      this.showSettingsModal('Privacy & Security');
    });

    settingsBtn3.addEventListener('click', () => {
      this.showSettingsModal('User Profile');
    });
  }

  navigateScreen(screenId) {
    const screens = document.querySelectorAll('.screen');
    const navButtons = document.querySelectorAll('.nav-btn');

    screens.forEach(screen => screen.classList.remove('active'));
    navButtons.forEach(btn => btn.classList.remove('active'));

    const targetScreen = document.getElementById(screenId.replace('Btn', 'Screen'));
    const targetButton = document.getElementById(screenId);

    targetScreen.classList.add('active');
    targetButton.classList.add('active');
  }

  createBudget(form) {
    const category = form.querySelector('select[name="category"]').value;
    const amount = parseFloat(form.querySelector('input[name="budgetAmount"]').value);

    const budget = { category, amount, id: Date.now() };
    this.budgets.push(budget);
    this.updateBudgetList();
    this.saveData();
    form.reset();
  }

  addExpense(form) {
    const category = form.querySelector('select[name="category"]').value;
    const amount = parseFloat(form.querySelector('input[name="expenseAmount"]').value);
    const date = form.querySelector('input[name="expenseDate"]').value;
    const note = form.querySelector('textarea[name="expenseNote"]').value;

    const expense = { category, amount, date, note, id: Date.now() };
    this.expenses.push(expense);
    this.updateExpenseList();
    this.updateBudgetProgress(category, amount);
    this.saveData();
    form.reset();
  }

  createReminder(form) {
    const title = form.querySelector('input[name="reminderTitle"]').value;
    const date = form.querySelector('input[name="reminderDate"]').value;
    const type = form.querySelector('select[name="reminderType"]').value;
    const note = form.querySelector('textarea[name="reminderNote"]').value;

    const reminder = { title, date, type, note, id: Date.now() };
    this.reminders.push(reminder);
    this.updateRemindersList();
    this.saveData();
    form.reset();
  }

  updateBudgetList() {
    const budgetList = document.getElementById('budgetList');
    budgetList.innerHTML = '';
    this.budgets.forEach(budget => {
      const li = document.createElement('li');
      li.innerHTML = `
        <span>${budget.category}</span>
        <span>KES ${budget.amount}</span>
        <button onclick="app.deleteBudget(${budget.id})">Delete</button>
      `;
      budgetList.appendChild(li);
    });
  }

  updateExpenseList() {
    const expenseList = document.getElementById('expenseList');
    expenseList.innerHTML = '';
    this.expenses.forEach(expense => {
      const li = document.createElement('li');
      li.innerHTML = `
        <span>${expense.category}</span>
        <span>KES ${expense.amount}</span>
        <span>${expense.date}</span>
      `;
      expenseList.appendChild(li);
    });
  }

  updateRemindersList() {
    const remindersList = document.getElementById('activeRemindersList');
    remindersList.innerHTML = '';
    this.reminders.forEach(reminder => {
      const li = document.createElement('li');
      li.innerHTML = `
        <span>${reminder.title}</span>
        <span>${reminder.date}</span>
        <button onclick="app.deleteReminder(${reminder.id})">Delete</button>
      `;
      remindersList.appendChild(li);
    });
  }

  updateBudgetProgress(category, amount) {
    // Budget categories are predefined as savings, transport, shaving, shopping
    const categories = ['savings', 'transport', 'shaving', 'shopping'];
    
    categories.forEach(categoryName => {
      if (categoryName === category.toLowerCase()) {
        const categoryElement = document.querySelector(`.budget-category[data-category="${categoryName}"]`);
        if (categoryElement) {
          const progressBar = categoryElement.querySelector('.progress');
          const currentAmount = parseFloat(categoryElement.querySelector('.current-amount').textContent.split('/')[0].replace('KES ', ''));
          const totalAmount = parseFloat(categoryElement.querySelector('.total-amount').textContent.split('/')[1].replace('KES ', ''));
          
          const newAmount = currentAmount + amount;
          const progressPercent = (newAmount / totalAmount) * 100;
          
          progressBar.style.width = `${Math.min(progressPercent, 100)}%`;
          categoryElement.querySelector('.current-amount').textContent = `KES ${newAmount.toFixed(0)} / ${totalAmount}`;
        }
      }
    });
  }

  updateSavings(action) {
    const amountToChange = parseFloat(document.getElementById('savingsInput').value);
    if (isNaN(amountToChange) || amountToChange <= 0) return; // Validate input
    
    if (action === 'add') {
      this.savings.amountSaved += amountToChange;
    } else if (action === 'withdraw') {
      this.savings.amountSaved = Math.max(0, this.savings.amountSaved - amountToChange); // Ensure it doesn't go negative
    }
    
    this.updateSavingsProgress();
    this.saveData();
  }

  updateSavingsProgress() {
    const progressBar = document.querySelector('.battery-progress');
    const progressPercent = (this.savings.amountSaved / this.savings.goal) * 100;
    
    progressBar.style.width = `${Math.min(progressPercent, 100)}%`;
    progressBar.textContent = `${Math.min(progressPercent, 100).toFixed(0)}%`;

    const savingsAmount = document.getElementById('savingsAmount');
    savingsAmount.textContent = `KES ${this.savings.amountSaved.toFixed(0)} / KES ${this.savings.goal}`;
  }

  saveTotalBalance() {
    const balanceInput = document.getElementById('balanceInput').value;
    if (isNaN(balanceInput) || balanceInput <= 0) return; // Validate input
    
    this.totalBalance = parseFloat(balanceInput);
    localStorage.setItem('totalBalance', this.totalBalance);
    document.getElementById('totalBalance').textContent = `KES ${this.totalBalance.toFixed(0)}`;
  }

  deleteBudget(id) {
    this.budgets = this.budgets.filter(budget => budget.id !== id);
    this.updateBudgetList();
    this.saveData();
  }

  deleteReminder(id) {
    this.reminders = this.reminders.filter(reminder => reminder.id !== id);
    this.updateRemindersList();
    this.saveData();
  }

  saveData() {
    localStorage.setItem('budgets', JSON.stringify(this.budgets));
    localStorage.setItem('expenses', JSON.stringify(this.expenses));
    localStorage.setItem('reminders', JSON.stringify(this.reminders));
    localStorage.setItem('savings', JSON.stringify(this.savings));
  }

  loadStoredData() {
    const storedBudgets = localStorage.getItem('budgets');
    const storedExpenses = localStorage.getItem('expenses');
    const storedReminders = localStorage.getItem('reminders');
    const storedSavings = localStorage.getItem('savings');
    const storedTotalBalance = localStorage.getItem('totalBalance');

    if (storedBudgets) this.budgets = JSON.parse(storedBudgets);
    if (storedExpenses) this.expenses = JSON.parse(storedExpenses);
    if (storedReminders) this.reminders = JSON.parse(storedReminders);
    if (storedSavings) this.savings = JSON.parse(storedSavings);
    if (storedTotalBalance) this.totalBalance = parseFloat(storedTotalBalance);

    this.updateBudgetList();
    this.updateExpenseList();
    this.updateRemindersList();
    this.updateSavingsProgress();
    document.getElementById('totalBalance').textContent = `KES ${this.totalBalance.toFixed(0)}`;
  }

  showSettingsModal(title) {
    // Create a modal for settings
    const modal = document.createElement('div');
    modal.classList.add('settings-modal');
    modal.innerHTML = `
      <div class="modal-content">
        <h2>${title}</h2>
        <p>Settings for ${title} will be implemented soon.</p>
        <button class="close-modal">Close</button>
      </div>
    `;
    
    document.body.appendChild(modal);

    // Close modal functionality
    const closeBtn = modal.querySelector('.close-modal');
    closeBtn.addEventListener('click', () => {
      document.body.removeChild(modal);
    });

    // Close modal if clicked outside
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        document.body.removeChild(modal);
      }
    });
  }
}

// Initialize the app when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  window.app = new FinancialTrackerApp();
});
